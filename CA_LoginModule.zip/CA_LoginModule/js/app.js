﻿/// <reference path="angular-route.js" />
/// <reference path="angular.min.js" />

var app = angular.module('caApp', ['ngRoute']);

app.config(function ($routeProvider) {
    $routeProvider.when('/login', {
        templateUrl: 'modules/login.html',
        controller: 'LoginCtrl'
    });

    $routeProvider.when('/home', {
        templateUrl: 'modules/home.html',
        controller: 'HomeCtrl'
    });

    $routeProvider.when("/clothTypeSelect", {
        templateUrl: "modules/clothTypeSelect.html",
        controller: "clothTypeSelectController",
        controllerAs: "clothTypeSelectCtrl"
    });

    $routeProvider.when("/menSubCategoriesSelect", {
        templateUrl: "modules/menSubCategoriesSelect.html",
        controller: "menSubCategoriesSelectController",
        controllerAs: "menSubCategoriesCtrl"
    });

    $routeProvider.otherwise({ redirectTo: '/login' });
});

app.run(function (authentication, $rootScope, $location) {
    $rootScope.$on('$routeChangeStart', function (evt) {
        if (!authentication.isAuthenticated) {
            $location.url("/login");
        }
        event.preventDefault();
    });
})

app.controller('LoginCtrl', function ($scope, $http, $location, authentication) {
    /*$scope.login = function () {
        if ($scope.username === 'admin' && $scope.password === 'pass') {
            console.log('successful')
            authentication.isAuthenticated = true;
            authentication.user = { name: $scope.username };
            $location.url("/");
        } else {
            $scope.loginError = "Invalid username/password combination";
            console.log('Login failed..');
            $scope.username = "";
            $scope.password = "";
        };
    };*/
});

app.controller('caAppCtrl', function ($scope, authentication, $rootScope) {
    $scope.templates =
  [
  	{ url: 'modules/login.html' },
    //{ url: 'modules/home.html' }
    {url: 'modules/clothTypeSelect.html' }
  ];
    $scope.template = $scope.templates[0];
    $scope.login = function (username, password) {
        if (username === 'admin' && password === '1234') {
            authentication.isAuthenticated = true;
            $scope.template = $scope.templates[1];
            $rootScope.user = username;
        } else {
            $scope.loginError = "Invalid username/password combination";
        };
    };

});

/*
app.controller('HomeCtrl', function ($rootScope, $scope, authentication, $location) {
    $scope.user = $rootScope.user;
    $scope.loadView = function () {
        $location.path("/clothTypeSelect");
    };
});*/

app.controller('clothTypeSelectCtrl', function () {
    $scope.menHyperlink = 'modules/men.html';
    $scope.womenHyperlink = 'modules/women.html';
    $scope.unisexHyperlink = 'modules/unisex.html';

    $scope.menIconImage = "../resources/men.png";
});

app.controller('menSubCategoriesCtrl', function () {


});


app.factory('authentication', function () {
    return {
        isAuthenticated: false,
        user: null
    }
});